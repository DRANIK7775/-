// Сайт розроблено студентом Ткаченко Дмитро, група 4-9з
const cityRates = {
    kyiv: 50,
    lviv: 60,
    odesa: 55,
    kharkiv: 52,
    dnipro: 53
};

const deliveryTypes = {
    standard: 1,
    express: 1.5,
    urgent: 2
};

const citySelect = document.getElementById('city');
const weightInput = document.getElementById('weight');
const typeSelect = document.getElementById('deliveryType');
const costSpan = document.getElementById('cost');

function calculateCost() {
    const city = citySelect.value;
    const weight = parseFloat(weightInput.value);
    const type = typeSelect.value;
    let baseRate = cityRates[city];
    let multiplier = deliveryTypes[type];
    let total = baseRate * weight * multiplier;
    costSpan.textContent = total.toFixed(2);
}

citySelect.addEventListener('input', calculateCost);
weightInput.addEventListener('input', calculateCost);
typeSelect.addEventListener('input', calculateCost);

// Початковий розрахунок
calculateCost();
